LANTERN original theme assets / 微光原创主题素材
Contains one desktop and one mobile original AI-generated illustration.
CC BY 4.0 applies only to rights held by project contributors; no exclusive rights are claimed in AI output. Credit: LANTERN 微光托业.
No official game characters, screenshots or third-party artwork are included.
All files retain their actual pixel size. WebP quality 94; not 4K.
Prompts and provenance: https://github.com/godnight/lantern-toeic/tree/main/art
